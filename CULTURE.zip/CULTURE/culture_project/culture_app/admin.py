from django.contrib import admin
from .models import ContactMessage, Comment

admin.site.register(ContactMessage)
admin.site.register(Comment)
