from django.apps import AppConfig


class CultureAppConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'culture_app'
